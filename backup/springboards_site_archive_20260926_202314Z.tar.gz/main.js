// Springboards for Community Development - Client Logic
document.addEventListener("DOMContentLoaded", () => {
  const yearSpan = document.getElementById("current-year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const navToggle = document.getElementById("navToggle");
  const navMenu = document.getElementById("navMenu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      navToggle.classList.toggle("active");
      navMenu.classList.toggle("open");
    });

    const navItems = navMenu.querySelectorAll("a");
    navItems.forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.classList.remove("active");
        navMenu.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });


    navMenu.querySelectorAll(".nav-dropdown-toggle").forEach((toggle) => {
      toggle.addEventListener("click", () => {
        const dropdown = toggle.closest(".nav-dropdown");
        const isOpen = dropdown.classList.toggle("open");
        toggle.setAttribute("aria-expanded", String(isOpen));
      });
    });

    document.addEventListener("click", (e) => {
      if (!navToggle.contains(e.target) && !navMenu.contains(e.target) && navMenu.classList.contains("open")) {
        navToggle.classList.remove("active");
        navMenu.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && navMenu.classList.contains("open")) {
        navToggle.classList.remove("active");
        navMenu.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
        navToggle.focus();
      }
    });
  }

  const sections = [
    { id: "our-mission", link: document.querySelector(".nav-link[href='#our-mission']") },
    { id: "our-programs", link: document.querySelector(".nav-link[href='#our-programs']") },
    { id: "our-service", link: document.querySelector(".nav-link[href='#our-service']") },
    { id: "footer", link: document.querySelector(".nav-link[href='#footer']") }
  ].filter(s => s.link && document.getElementById(s.id));

  function updateActiveLink() {
    const scrollPos = window.scrollY + 180;
    let currentId = null;
    for (let i = sections.length - 1; i >= 0; i--) {
      const el = document.getElementById(sections[i].id);
      if (el && el.offsetTop <= scrollPos) {
        currentId = sections[i].id;
        break;
      }
    }
    sections.forEach(({ id, link }) => {
      if (id === currentId) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    });
  }

  window.addEventListener("scroll", updateActiveLink, { passive: true });
  updateActiveLink();

  const impactSlides = document.querySelectorAll(".impact-slide");
  const impactButtons = document.querySelectorAll(".impact-carousel-button");
  impactButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const selectedSlide = Number(button.dataset.slide);
      impactSlides.forEach((slide, index) => {
        slide.classList.toggle("is-active", index === selectedSlide);
      });
      impactButtons.forEach((control, index) => {
        control.setAttribute("aria-pressed", String(index === selectedSlide));
      });
    });

  });

    // ACCESSIBLE PROGRAM CARDS
  const flipProgramCard = (card, shouldFlip) => {
    card.classList.toggle("is-flipped", shouldFlip);
    card.setAttribute("aria-expanded", String(shouldFlip));
    const cardProgram = card.dataset.programCard || "program";
    const programTitle = cardProgram.charAt(0).toUpperCase() + cardProgram.slice(1);
    card.setAttribute("aria-label", shouldFlip ? `Hide details for ${programTitle}` : `Show details for ${programTitle}`);
    
    const frontFace = card.querySelector(".program-card-front");
    const backFace = card.querySelector(".program-card-back");
    if (frontFace && backFace) {
      frontFace.setAttribute("aria-hidden", String(shouldFlip));
      backFace.setAttribute("aria-hidden", String(!shouldFlip));
    }
  };

  document.querySelectorAll(".program-card-flip").forEach((card) => {
    card.addEventListener("click", (event) => {
      if (event.target.closest("form, input, button, a")) {
        return;
      }
      flipProgramCard(card, !card.classList.contains("is-flipped"));
    });
    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        flipProgramCard(card, !card.classList.contains("is-flipped"));
      }
    });
  });

  // Handle jump links that specifically target a program card (Learn, Train, Build)
  document.querySelectorAll("[data-flip-target]").forEach((link) => {
    link.addEventListener("click", () => {
      const target = link.dataset.flipTarget;
      const targetCard = document.querySelector(`[data-program-card="${target}"]`);
      if (targetCard) {
        setTimeout(() => {
          flipProgramCard(targetCard, true);
          targetCard.focus();
        }, 350);
      }
    });
  });

  // MODAL FOCUS TRAPPING & ACCESSIBILITY MANAGEMENT
  let lastActiveModalTrigger = null;

  const openModalWithFocus = (modal, initialElement) => {
    lastActiveModalTrigger = document.activeElement;
    modal.hidden = false;
    document.body.classList.add("modal-open");
    if (initialElement && typeof initialElement.focus === "function") {
      initialElement.focus();
    }
  };

  const closeModalWithFocus = (modal) => {
    modal.hidden = true;
    document.body.classList.remove("modal-open");
    if (lastActiveModalTrigger && typeof lastActiveModalTrigger.focus === "function") {
      lastActiveModalTrigger.focus();
      lastActiveModalTrigger = null;
    }
  };

  // Global trap for Tab and Escape across all modals
  document.addEventListener("keydown", (event) => {
    const activeModal = document.querySelector(".inquiry-modal:not([hidden])");
    if (!activeModal) return;

    if (event.key === "Escape") {
      closeModalWithFocus(activeModal);
      return;
    }

    if (event.key === "Tab") {
      const focusable = activeModal.querySelectorAll(
        'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (!focusable.length) return;

      const firstItem = focusable[0];
      const lastItem = focusable[focusable.length - 1];

      if (event.shiftKey) {
        if (document.activeElement === firstItem) {
          event.preventDefault();
          lastItem.focus();
        }
      } else {
        if (document.activeElement === lastItem) {
          event.preventDefault();
          firstItem.focus();
        }
      }
    }
  });

  // PHONE AUTO-FORMATTING & VALIDATION HELPERS
  const formatPhoneNumber = (value) => {
    if (!value) return value;
    const phoneNumber = value.replace(/[^\d]/g, "");
    const phoneNumberLength = phoneNumber.length;
    if (phoneNumberLength < 4) return phoneNumber;
    if (phoneNumberLength < 7) {
      return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
    }
    return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
  };

  const isValidEmail = (email) => {
    if (!email) return false;
    return /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/.test(email.trim());
  };

  const isValidPhone = (phone) => {
    if (!phone) return false;
    const digits = phone.replace(/[^\d]/g, "");
    return digits.length === 10 || (digits.length === 11 && digits.startsWith("1"));
  };

  // Attach phone formatting mask to all tel inputs
  document.querySelectorAll('input[type="tel"]').forEach((input) => {
    input.addEventListener("input", (e) => {
      const formatted = formatPhoneNumber(e.target.value);
      e.target.value = formatted;
      e.target.classList.remove("is-invalid");
    });
  });

  document.querySelectorAll('input[type="email"], input[type="text"]').forEach((input) => {
    input.addEventListener("input", (e) => {
      e.target.classList.remove("is-invalid");
      const form = e.target.closest("form");
      if (form) {
        const status = form.querySelector(".form-status");
        if (status) status.textContent = "";
      }
    });
  });

  // PROGRAM INQUIRY MODAL & CONFIRMATION
  const inquiryModal = document.getElementById("inquiryModal");
  const inquiryModalTitle = document.getElementById("inquiryModalTitle");
  const inquiryModalDescription = document.getElementById("inquiryModalDescription");
  const inquiryFormView = document.getElementById("inquiryFormView");
  const inquiryConfirmationScreen = document.getElementById("inquiryConfirmationScreen");
  const inquiryForm = document.getElementById("programInquiryForm");
  const inquiryDetails = {
    Learn: "Ready to start trade training and certifications? Share one way to reach you and we will follow up about enrollment.",
    Train: "To begin Transitional Jobs or OJT, participants must first be verified through a career center and referred to a participating worksite. Share one way to reach you and we will help point you to the next step.",
    Build: "Interested in apprenticeship? Share one way to reach you and we will follow up with current pathway information and next steps."
  };

  if (inquiryModal && inquiryForm) {
    document.querySelectorAll(".program-inquiry-button").forEach((button) => {
      button.addEventListener("click", () => {
        // Reset to form view
        inquiryForm.reset();
        inquiryFormView.hidden = false;
        inquiryConfirmationScreen.hidden = true;
        inquiryForm.querySelectorAll(".is-invalid").forEach(el => el.classList.remove("is-invalid"));
        inquiryForm.elements.program.value = button.dataset.program;
        inquiryModalTitle.textContent = `${button.dataset.program} program inquiry`;
        inquiryModalDescription.textContent = inquiryDetails[button.dataset.program] || "Share your contact details.";
        const status = inquiryForm.querySelector(".form-status");
        status.textContent = "";
        status.classList.remove("is-error");
        openModalWithFocus(inquiryModal, inquiryForm.elements.name);
      });
    });

    document.querySelectorAll("[data-inquiry-close]").forEach((control) => {
      control.addEventListener("click", () => {
        closeModalWithFocus(inquiryModal);
      });
    });

    inquiryForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const status = inquiryForm.querySelector(".form-status");
      const submit = inquiryForm.querySelector(".program-submit");
      const program = inquiryForm.elements.program.value;
      const formData = new FormData(inquiryForm);
      const name = String(formData.get("name") || "").trim();
      const phone = String(formData.get("phone") || "").trim();
      const email = String(formData.get("email") || "").trim();

      status.classList.remove("is-error");
      inquiryForm.querySelectorAll(".is-invalid").forEach(el => el.classList.remove("is-invalid"));

      // 1. Validate Name
      if (!name || name.length < 2) {
        status.classList.add("is-error");
        status.textContent = "Please enter your full name (minimum 2 characters).";
        inquiryForm.elements.name.classList.add("is-invalid");
        inquiryForm.elements.name.focus();
        return;
      }

      // 2. Validate at least one contact method
      if (!phone && !email) {
        status.classList.add("is-error");
        status.textContent = "Please provide either a phone number or email address.";
        inquiryForm.elements.phone.classList.add("is-invalid");
        inquiryForm.elements.email.classList.add("is-invalid");
        inquiryForm.elements.phone.focus();
        return;
      }

      // 3. Validate Phone format if provided
      if (phone && !isValidPhone(phone)) {
        status.classList.add("is-error");
        status.textContent = "Please enter a valid 10-digit phone number, e.g. (334) 556-1234.";
        inquiryForm.elements.phone.classList.add("is-invalid");
        inquiryForm.elements.phone.focus();
        return;
      }

      // 4. Validate Email format if provided
      if (email && !isValidEmail(email)) {
        status.classList.add("is-error");
        status.textContent = "Please enter a valid email address (e.g. name@example.com).";
        inquiryForm.elements.email.classList.add("is-invalid");
        inquiryForm.elements.email.focus();
        return;
      }

      // Honeypot anti-spam check (silent deflection)
      const honeypot = formData.get("website_url");
      if (honeypot) {
        inquiryFormView.hidden = true;
        inquiryConfirmationScreen.hidden = false;
        inquiryForm.reset();
        return;
      }

      submit.disabled = true;
      status.textContent = "Sending your inquiry...";

      try {
        let delivered = false;
        // Attempt primary delivery via server proxy
        try {
          const res = await fetch("/api/inquiries", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, phone, email, program })
          });
          if (res.ok) {
            delivered = true;
          }
        } catch {
          // Server endpoint fallback
        }

        // Secondary fallback directly to Firestore REST API if needed
        if (!delivered) {
          const directRes = await fetch(
            "https://firestore.googleapis.com/v1/projects/springboards-community-dev/databases/(default)/documents/programInquiries",
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                fields: {
                  program: { stringValue: program },
                  tag: { stringValue: `program-${program.toLowerCase()}` },
                  name: { stringValue: name },
                  phone: { stringValue: phone },
                  email: { stringValue: email },
                  deliveredTo: { stringValue: "info@springboardsfcd.org" },
                  createdAt: { timestampValue: new Date().toISOString() }
                }
              })
            }
          );
          if (!directRes.ok) {
            throw new Error(`Inquiry submission failed with status ${directRes.status}.`);
          }
        }

        // Show Confirmation Screen
        inquiryFormView.hidden = true;
        inquiryConfirmationScreen.hidden = false;
        const confirmName = inquiryConfirmationScreen.querySelector(".confirm-name");
        const confirmProgram = inquiryConfirmationScreen.querySelector(".confirm-program");
        if (confirmName) confirmName.textContent = name;
        if (confirmProgram) confirmProgram.textContent = program;

        const doneButton = inquiryConfirmationScreen.querySelector(".confirmation-done-button");
        if (doneButton) doneButton.focus();

        inquiryForm.reset();
      } catch (error) {
        console.error(error);
        status.classList.add("is-error");
        status.textContent = "We could not deliver this inquiry right now. Please try again or email info@springboardsfcd.org.";
      } finally {
        submit.disabled = false;
      }
    });
  }

  // VOLUNTEER INTEREST INQUIRY MODAL & CONFIRMATION
  const volunteerSignupModal = document.getElementById("volunteerSignupModal");
  const volunteerFormView = document.getElementById("volunteerFormView");
  const volunteerConfirmationScreen = document.getElementById("volunteerConfirmationScreen");
  const volunteerSignupForm = document.getElementById("volunteerSignupForm");

  if (volunteerSignupModal && volunteerSignupForm) {
    document.querySelectorAll(".event-signup-button").forEach((button) => {
      button.addEventListener("click", () => {
        volunteerSignupForm.reset();
        volunteerFormView.hidden = false;
        volunteerConfirmationScreen.hidden = true;
        volunteerSignupForm.querySelectorAll(".is-invalid").forEach(el => el.classList.remove("is-invalid"));
        const status = volunteerSignupForm.querySelector(".form-status");
        status.textContent = "";
        status.classList.remove("is-error");
        const nameField = volunteerSignupForm.elements.name;
        openModalWithFocus(volunteerSignupModal, nameField);
      });
    });

    document.querySelectorAll("[data-volunteer-close]").forEach((control) => {
      control.addEventListener("click", () => {
        closeModalWithFocus(volunteerSignupModal);
      });
    });

    volunteerSignupForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const status = volunteerSignupForm.querySelector(".form-status");
      const submit = volunteerSignupForm.querySelector(".program-submit");
      const formData = new FormData(volunteerSignupForm);
      const name = String(formData.get("name") || "").trim();
      const phone = String(formData.get("phone") || "").trim();
      const email = String(formData.get("email") || "").trim();
      const availability = String(formData.get("availability") || "flexible").trim();
      const interest = String(formData.get("interest") || "general").trim();

      status.classList.remove("is-error");
      volunteerSignupForm.querySelectorAll(".is-invalid").forEach(el => el.classList.remove("is-invalid"));

      // 1. Validate Name
      if (!name || name.length < 2) {
        status.classList.add("is-error");
        status.textContent = "Please enter your full name (minimum 2 characters).";
        volunteerSignupForm.elements.name.classList.add("is-invalid");
        volunteerSignupForm.elements.name.focus();
        return;
      }

      // 2. Validate at least one contact method
      if (!phone && !email) {
        status.classList.add("is-error");
        status.textContent = "Please provide either a phone number or email address.";
        volunteerSignupForm.elements.phone.classList.add("is-invalid");
        volunteerSignupForm.elements.email.classList.add("is-invalid");
        volunteerSignupForm.elements.phone.focus();
        return;
      }

      // 3. Validate Phone format if provided
      if (phone && !isValidPhone(phone)) {
        status.classList.add("is-error");
        status.textContent = "Please enter a valid 10-digit phone number, e.g. (334) 556-1234.";
        volunteerSignupForm.elements.phone.classList.add("is-invalid");
        volunteerSignupForm.elements.phone.focus();
        return;
      }

      // 4. Validate Email format if provided
      if (email && !isValidEmail(email)) {
        status.classList.add("is-error");
        status.textContent = "Please enter a valid email address (e.g. name@example.com).";
        volunteerSignupForm.elements.email.classList.add("is-invalid");
        volunteerSignupForm.elements.email.focus();
        return;
      }

      // Honeypot anti-spam check (silent deflection)
      const honeypot = formData.get("website_url");
      if (honeypot) {
        volunteerFormView.hidden = true;
        volunteerConfirmationScreen.hidden = false;
        volunteerSignupForm.reset();
        return;
      }

      submit.disabled = true;
      status.textContent = "Submitting your volunteer interest...";

      try {
        let delivered = false;
        try {
          const res = await fetch("/api/volunteer-signups", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, phone, email, availability, interest })
          });
          if (res.ok) {
            delivered = true;
          }
        } catch {
          // Server endpoint fallback
        }

        if (!delivered) {
          const directRes = await fetch(
            "https://firestore.googleapis.com/v1/projects/springboards-community-dev/databases/(default)/documents/volunteerSignups",
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                fields: {
                  event: { stringValue: "General Volunteer Interest" },
                  location: { stringValue: "Springboards Community Center" },
                  availability: { stringValue: availability },
                  interest: { stringValue: interest },
                  name: { stringValue: name },
                  phone: { stringValue: phone },
                  email: { stringValue: email },
                  deliveredTo: { stringValue: "info@springboardsfcd.org" },
                  createdAt: { timestampValue: new Date().toISOString() }
                }
              })
            }
          );
          if (!directRes.ok) {
            throw new Error(`Volunteer interest submission failed with status ${directRes.status}.`);
          }
        }

        // Show Confirmation Screen
        volunteerFormView.hidden = true;
        volunteerConfirmationScreen.hidden = false;
        const confirmName = volunteerConfirmationScreen.querySelector(".confirm-name");
        const confirmInterest = volunteerConfirmationScreen.querySelector(".confirm-interest");
        if (confirmName) confirmName.textContent = name;
        if (confirmInterest) {
          const interestLabels = {
            "cleaning-demo": "cleaning and demo support",
            "tools-prep": "tools and safety preparation",
            "community-outreach": "community outreach",
            "general": "general community support"
          };
          confirmInterest.textContent = interestLabels[interest] || interest;
        }

        const doneButton = volunteerConfirmationScreen.querySelector(".confirmation-done-button");
        if (doneButton) doneButton.focus();

        volunteerSignupForm.reset();
      } catch (error) {
        console.error(error);
        status.classList.add("is-error");
        status.textContent = "We could not save your submission. Please try again or email info@springboardsfcd.org.";
      } finally {
        submit.disabled = false;
      }
    });
  }

  // PRIVACY POLICY & TERMS MODAL
  const privacyModal = document.getElementById("privacyModal");
  const openPrivacyBtn = document.getElementById("openPrivacyModal");
  if (privacyModal && openPrivacyBtn) {
    openPrivacyBtn.addEventListener("click", () => {
      openModalWithFocus(privacyModal, privacyModal.querySelector(".btn-cta"));
    });
    privacyModal.querySelectorAll("[data-privacy-close]").forEach((btn) => {
      btn.addEventListener("click", () => {
        closeModalWithFocus(privacyModal);
      });
    });
  }

  // BACK TO TOP FLOATING BUTTON
  const backToTopBtn = document.getElementById("backToTop");
  if (backToTopBtn) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 400) {
        backToTopBtn.hidden = false;
        backToTopBtn.classList.add("is-visible");
      } else {
        backToTopBtn.classList.remove("is-visible");
      }
    }, { passive: true });

    backToTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // TOAST NOTIFICATION HELPER
  const toast = document.getElementById("toastNotification");
  let toastTimer = null;
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.hidden = false;
    // Force reflow for animation
    void toast.offsetWidth;
    toast.classList.add("is-active");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove("is-active");
      setTimeout(() => { toast.hidden = true; }, 300);
    }, 3200);
  };

  // COMMUNITY SHARE PAGE TRIGGER
  const shareBtn = document.getElementById("sharePageButton");
  if (shareBtn) {
    shareBtn.addEventListener("click", async () => {
      if (navigator.share) {
        try {
          await navigator.share({
            title: "Springboards for Community Development",
            text: "Debt-free trade training and career pathways in West Georgia & East Alabama.",
            url: window.location.href
          });
        } catch {
          // Cancelled by user
        }
      } else if (navigator.clipboard) {
        try {
          await navigator.clipboard.writeText(window.location.href);
          showToast("Page link copied to clipboard!");
        } catch {
          showToast("Visit springboardsfcd.org to share!");
        }
      } else {
        showToast("Visit springboardsfcd.org to share!");
      }
    });
  }
});
