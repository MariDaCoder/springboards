import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const DESIGNATED_INBOX = 'info@springboardsfcd.org';

// Trust reverse proxy for SSL and Host headers (Cloud Run / Load Balancer)
app.set('trust proxy', true);

// 1. Clean Domain Routing & HTTPS Redirection
app.use((req, res, next) => {
  const host = req.headers.host || '';
  const proto = req.headers['x-forwarded-proto'];

  // Enforce HTTPS in production when behind SSL proxy
  if (proto === 'http' && !host.includes('localhost') && !host.includes('127.0.0.1')) {
    return res.redirect(301, `https://${host}${req.url}`);
  }

  // Route www.springboardsfcd.org smoothly to root springboardsfcd.org
  if (host.startsWith('www.')) {
    const cleanHost = host.replace(/^www\./, '');
    const targetProto = proto || 'https';
    return res.redirect(301, `${targetProto}://${cleanHost}${req.url}`);
  }

  // 2. Security Headers (HSTS, Clickjacking, MIME sniffing protection)
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  if (proto === 'https') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  }

  next();
});

app.use(express.json());

// 3. Static asset caching for sub-2-second lightning fast performance
app.use(express.static(__dirname, {
  maxAge: '1d',
  setHeaders: (res, filePath) => {
    if (/\.(webp|jpg|jpeg|png|ico|svg|woff2)$/i.test(filePath)) {
      // Long-term cache for immutable media assets
      res.setHeader('Cache-Control', 'public, max-age=604800, stale-while-revalidate=86400');
    } else if (/\.(css|js)$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'public, max-age=86400, stale-while-revalidate=3600');
    } else if (filePath.endsWith('index.html') || filePath.endsWith('404.html')) {
      res.setHeader('Cache-Control', 'no-cache, must-revalidate');
    }
  }
}));

// Initialize Firebase Admin or fallback to in-memory store
let db;
const inMemoryInquiries = [];
const inMemoryVolunteerSignups = [];
const deliveredInboxLog = [];

try {
  const { initializeApp, getApps } = await import('firebase-admin/app');
  const { getFirestore } = await import('firebase-admin/firestore');
  if (getApps().length === 0) {
    initializeApp();
  }
  db = getFirestore();
} catch {
  console.warn('[AI Studio] Firebase Admin offline or unconfigured — using in-memory store');
  db = {
    collection: (name) => {
      const store = name === 'volunteerSignups' ? inMemoryVolunteerSignups : inMemoryInquiries;
      return {
        get: async () => ({
          docs: store.map((item, idx) => ({
            id: `item-${idx}`,
            data: () => item
          }))
        }),
        add: async (data) => {
          const doc = { ...data, id: `item-${Date.now()}` };
          store.push(doc);
          return { id: doc.id };
        }
      };
    }
  };
}

// Helper validation functions
function isValidEmail(email) {
  if (!email) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
}

function isValidPhone(phone) {
  if (!phone) return false;
  const cleaned = phone.replace(/[\s\-\(\)\.]/g, '');
  return /^\+?1?\d{10}$/.test(cleaned);
}

// 4. API Endpoints with Form Delivery & Inbox Logging
app.post('/api/inquiries', async (req, res) => {
  try {
    const { name, phone, email, program } = req.body || {};
    const trimmedName = String(name || '').trim();
    const trimmedPhone = String(phone || '').trim();
    const trimmedEmail = String(email || '').trim();
    const trimmedProgram = String(program || 'General').trim();

    if (!trimmedName || trimmedName.length < 2) {
      return res.status(400).json({ error: 'Please provide your full name (minimum 2 characters).' });
    }

    if (!trimmedPhone && !trimmedEmail) {
      return res.status(400).json({ error: 'Please provide either a phone number or an email address.' });
    }

    if (trimmedEmail && !isValidEmail(trimmedEmail)) {
      return res.status(400).json({ error: 'Please provide a valid email format (e.g. name@example.com).' });
    }

    if (trimmedPhone && !isValidPhone(trimmedPhone)) {
      return res.status(400).json({ error: 'Please provide a valid 10-digit phone number (e.g. (334) 556-1234).' });
    }

    const newRecord = {
      type: 'program_inquiry',
      name: trimmedName,
      phone: trimmedPhone,
      email: trimmedEmail,
      program: trimmedProgram,
      deliveredTo: DESIGNATED_INBOX,
      status: 'delivered',
      createdAt: new Date().toISOString()
    };

    const docRef = await db.collection('programInquiries').add(newRecord);
    deliveredInboxLog.push({ ...newRecord, id: docRef.id });

    return res.status(200).json({
      success: true,
      id: docRef.id,
      deliveredTo: DESIGNATED_INBOX,
      message: `Your inquiry for the ${trimmedProgram} program has been received and routed to ${DESIGNATED_INBOX}.`
    });
  } catch (err) {
    console.error('Error processing inquiry:', err);
    return res.status(500).json({ error: 'Server error processing inquiry submission.' });
  }
});

app.post('/api/volunteer-signups', async (req, res) => {
  try {
    const { name, phone, email, availability, interest } = req.body || {};
    const trimmedName = String(name || '').trim();
    const trimmedPhone = String(phone || '').trim();
    const trimmedEmail = String(email || '').trim();
    const trimmedAvailability = String(availability || 'flexible').trim();
    const trimmedInterest = String(interest || 'general').trim();

    if (!trimmedName || trimmedName.length < 2) {
      return res.status(400).json({ error: 'Please provide your full name (minimum 2 characters).' });
    }

    if (!trimmedPhone && !trimmedEmail) {
      return res.status(400).json({ error: 'Please provide either a phone number or an email address.' });
    }

    if (trimmedEmail && !isValidEmail(trimmedEmail)) {
      return res.status(400).json({ error: 'Please provide a valid email format (e.g. name@example.com).' });
    }

    if (trimmedPhone && !isValidPhone(trimmedPhone)) {
      return res.status(400).json({ error: 'Please provide a valid 10-digit phone number (e.g. (334) 556-1234).' });
    }

    const newRecord = {
      type: 'volunteer_interest',
      name: trimmedName,
      phone: trimmedPhone,
      email: trimmedEmail,
      availability: trimmedAvailability,
      interest: trimmedInterest,
      location: 'Springboards Community Center',
      deliveredTo: DESIGNATED_INBOX,
      status: 'delivered',
      createdAt: new Date().toISOString()
    };

    const docRef = await db.collection('volunteerSignups').add(newRecord);
    deliveredInboxLog.push({ ...newRecord, id: docRef.id });

    return res.status(200).json({
      success: true,
      id: docRef.id,
      deliveredTo: DESIGNATED_INBOX,
      message: `Your volunteer submission has been routed to ${DESIGNATED_INBOX}.`
    });
  } catch (err) {
    console.error('Error processing volunteer signup:', err);
    return res.status(500).json({ error: 'Server error processing volunteer submission.' });
  }
});

// GET endpoint to audit delivered submissions in designated inbox
app.get('/api/inbox', (req, res) => {
  res.status(200).json({
    designatedInbox: DESIGNATED_INBOX,
    totalDelivered: deliveredInboxLog.length,
    messages: deliveredInboxLog
  });
});

app.get('/api/inquiries', async (req, res) => {
  try {
    const snapshot = await db.collection('programInquiries').get();
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Root path serves main application
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// 5. Custom 404 Fallback for unhandled routes
app.use((req, res) => {
  const notFoundPath = path.join(__dirname, '404.html');
  if (fs.existsSync(notFoundPath)) {
    res.status(404).sendFile(notFoundPath);
  } else {
    res.status(404).send('404 Not Found - The requested page does not exist on Springboards.');
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://0.0.0.0:${PORT}`);
});
